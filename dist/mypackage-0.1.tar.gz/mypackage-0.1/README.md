# mypackage

This package was created as an example of how to publish your own Python package.

## building this package locally
'python setup.py sdist'

## installing this package from Github

## updating this package from github

